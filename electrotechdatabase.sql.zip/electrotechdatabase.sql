-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2024 at 07:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `electrotechdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add customers', 7, 'add_customers'),
(26, 'Can change customers', 7, 'change_customers'),
(27, 'Can delete customers', 7, 'delete_customers'),
(28, 'Can view customers', 7, 'view_customers'),
(29, 'Can add products', 8, 'add_products'),
(30, 'Can change products', 8, 'change_products'),
(31, 'Can delete products', 8, 'delete_products'),
(32, 'Can view products', 8, 'view_products'),
(33, 'Can add cart', 9, 'add_cart'),
(34, 'Can change cart', 9, 'change_cart'),
(35, 'Can delete cart', 9, 'delete_cart'),
(36, 'Can view cart', 9, 'view_cart'),
(37, 'Can add payment', 10, 'add_payment'),
(38, 'Can change payment', 10, 'change_payment'),
(39, 'Can delete payment', 10, 'delete_payment'),
(40, 'Can view payment', 10, 'view_payment'),
(41, 'Can add favourites', 11, 'add_favourites'),
(42, 'Can change favourites', 11, 'change_favourites'),
(43, 'Can delete favourites', 11, 'delete_favourites'),
(44, 'Can view favourites', 11, 'view_favourites'),
(45, 'Can add like', 12, 'add_like'),
(46, 'Can change like', 12, 'change_like'),
(47, 'Can delete like', 12, 'delete_like'),
(48, 'Can view like', 12, 'view_like');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$600000$YxTfYf2zzdBELzCBDJIgrf$9VVHl89BVc8QyZkPyRwMuGBU4Zqi8fM60fLz11zXld8=', '2024-06-05 09:49:55.669854', 1, 'admin', '', '', 'admin@gmail.com', 1, 1, '2024-05-18 07:27:15.711159');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2024-05-18 08:33:55.152878', '1', 'Products object (1)', 1, '[{\"added\": {}}]', 8, 1),
(2, '2024-05-18 09:22:15.742303', '2', 'Products object (2)', 1, '[{\"added\": {}}]', 8, 1),
(3, '2024-05-18 09:24:28.860267', '3', 'Products object (3)', 1, '[{\"added\": {}}]', 8, 1),
(4, '2024-05-23 10:58:03.736619', '4', 'LG 322 L 3 Star Frost', 1, '[{\"added\": {}}]', 8, 1),
(5, '2024-05-23 10:59:49.931657', '5', 'SAMSUNG 633 Litres', 1, '[{\"added\": {}}]', 8, 1),
(6, '2024-05-23 11:01:57.185694', '6', 'Longway Super Dlx 750 Watt Juicer', 1, '[{\"added\": {}}]', 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(9, 'eletrotechapp', 'cart'),
(7, 'eletrotechapp', 'customers'),
(11, 'eletrotechapp', 'favourites'),
(12, 'eletrotechapp', 'like'),
(10, 'eletrotechapp', 'payment'),
(8, 'eletrotechapp', 'products'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2024-05-02 13:36:14.668289'),
(2, 'auth', '0001_initial', '2024-05-02 13:36:16.324426'),
(3, 'admin', '0001_initial', '2024-05-02 13:36:16.581069'),
(4, 'admin', '0002_logentry_remove_auto_add', '2024-05-02 13:36:16.599060'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2024-05-02 13:36:16.622072'),
(6, 'contenttypes', '0002_remove_content_type_name', '2024-05-02 13:36:16.760585'),
(7, 'auth', '0002_alter_permission_name_max_length', '2024-05-02 13:36:16.898572'),
(8, 'auth', '0003_alter_user_email_max_length', '2024-05-02 13:36:16.933553'),
(9, 'auth', '0004_alter_user_username_opts', '2024-05-02 13:36:16.960537'),
(10, 'auth', '0005_alter_user_last_login_null', '2024-05-02 13:36:17.166189'),
(11, 'auth', '0006_require_contenttypes_0002', '2024-05-02 13:36:17.170404'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2024-05-02 13:36:17.189725'),
(13, 'auth', '0008_alter_user_username_max_length', '2024-05-02 13:36:17.239666'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2024-05-02 13:36:17.265052'),
(15, 'auth', '0010_alter_group_name_max_length', '2024-05-02 13:36:17.295835'),
(16, 'auth', '0011_update_proxy_permissions', '2024-05-02 13:36:17.310818'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2024-05-02 13:36:17.342150'),
(18, 'eletrotechapp', '0001_initial', '2024-05-02 13:36:17.374663'),
(19, 'sessions', '0001_initial', '2024-05-02 13:36:17.443449'),
(20, 'eletrotechapp', '0002_rename_phonenumber_customers_mobile_and_more', '2024-05-18 04:54:18.855065'),
(21, 'eletrotechapp', '0003_products', '2024-05-18 07:23:17.154949'),
(22, 'eletrotechapp', '0004_cart', '2024-05-18 09:52:36.554019'),
(23, 'eletrotechapp', '0005_payment', '2024-05-20 07:19:51.937651'),
(24, 'eletrotechapp', '0006_favourites', '2024-06-05 06:29:15.414870'),
(25, 'eletrotechapp', '0007_cart_quantity', '2024-06-05 07:34:02.235710'),
(26, 'eletrotechapp', '0008_like', '2024-07-15 10:56:53.344171'),
(27, 'eletrotechapp', '0009_remove_like_created_at_like_like_products_likes', '2024-07-16 05:27:08.373198');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('640cetrnmamyrru50uvi2c8y95t0gclz', '.eJxVjDsOgzAQRO_iOrKw8Tdles5g7XqXmCQyEoYqyt0DEkWi6ea9mbdIsK0lbY2XNJG4CiUuvx1CfnI9AD2g3meZ57ouE8pDkSdtcpiJX7fT_Tso0Mq-towuku-MDh7ZKyAMvTNxNL0OGO0eJtCEgJFcl33OZI1R2iqr0Y3i8wXiRDfh:1sEoA6:k0s73EI5v3tIlkiLkRtoWL2pqoAyZjbPR-T402mBgH4', '2024-06-19 10:46:34.446954'),
('75lr5hi1uvc3b6npezrxoc9up8jzuolg', 'eyJpZCI6MX0:1sV2aK:c0StsC2HldYIMScdMTqsdHjB3ZYF_1Ln5ItM4BMAiaY', '2024-08-03 05:24:44.075786'),
('a3ty171sn0j4wpidli3k1hu3k13h5pfy', 'e30:1sF49G:t5V12rGn3ET483jEn78REVXkhaAOFfNVufOOIGXU3nM', '2024-06-20 03:50:46.120505'),
('mud3gnumahbv27ee99xjc4e9scue1yxq', '.eJxVjDsOgzAQRO_iOrKw8Tdles5g7XqXmCQyEoYqyt0DEkWi6ea9mbdIsK0lbY2XNJG4CiUuvx1CfnI9AD2g3meZ57ouE8pDkSdtcpiJX7fT_Tso0Mq-towuku-MDh7ZKyAMvTNxNL0OGO0eJtCEgJFcl33OZI1R2iqr0Y3i8wXiRDfh:1sARXd:X1-cAfqq7XAW2cdPMo-19-70zCs4P0C5BVyMRbq06-U', '2024-06-07 09:48:49.050690'),
('s2552v8do6r5y7k1mlb1176e35owh3v3', '.eJxVjssOwiAURP-FtSE8ykOX7v0Gwr1cpGogKe3K-O-WpAvdzpw5mTcLcVtL2DotYU7swiQ7_WYQ8Ul1FOkR671xbHVdZuAD4Ufb-a0lel0P9k9QYi_72kfQiEZ5ZSBnQecpSwAtJnKYhFKWrDYiTZEykdHZWO_2CQnrNCAM6bgnP1-Najpd:1s8HbP:8WMa2rwHO_TsxxKQLQhDet1dgKSSz7XwuXKtec54KHk', '2024-06-01 10:47:47.864553'),
('svrmlwr7pmlbxya8fsff60ra2k1oelqq', '.eJxVjDsOgzAQRO_iOrKw8Tdles5g7XqXmCQyEoYqyt0DEkWi6ea9mbdIsK0lbY2XNJG4CiUuvx1CfnI9AD2g3meZ57ouE8pDkSdtcpiJX7fT_Tso0Mq-towuku-MDh7ZKyAMvTNxNL0OGO0eJtCEgJFcl33OZI1R2iqr0Y3i8wXiRDfh:1sA64o:CIdTr8e6mG67l-EOiebHNU6MnWnUPvhg13n6ayewKuc', '2024-06-06 10:53:38.305429'),
('yqv68qoy7fhmi3gwthgzk9thq7tcderm', 'eyJpZCI6MX0:1t61gN:l_1JEu6Z7fTNAaD1mXdoKGI6uGCCGwrHPjfyWT9mVdw', '2024-11-13 05:55:51.680909'),
('zy446gv36ron5f9sfmfane30betvvod2', 'eyJpZCI6MX0:1sTJTa:tKw533w5VW0QH4vu6swlZIjNBSnIWg8vdYRt0XWVWDk', '2024-07-29 11:02:38.637722');

-- --------------------------------------------------------

--
-- Table structure for table `eletrotechapp_cart`
--

CREATE TABLE `eletrotechapp_cart` (
  `id` bigint(20) NOT NULL,
  `Price` int(11) NOT NULL,
  `ProductID_id` bigint(20) NOT NULL,
  `UserID_id` bigint(20) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eletrotechapp_customers`
--

CREATE TABLE `eletrotechapp_customers` (
  `id` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Address` longtext NOT NULL,
  `Country` varchar(100) NOT NULL,
  `District` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eletrotechapp_customers`
--

INSERT INTO `eletrotechapp_customers` (`id`, `UserName`, `Email`, `Mobile`, `Password`, `Address`, `Country`, `District`) VALUES
(1, 'customer', 'customer1@gmail.com', 9876543210, '123', 'thrissur house', 'India', 'thrissur');

-- --------------------------------------------------------

--
-- Table structure for table `eletrotechapp_favourites`
--

CREATE TABLE `eletrotechapp_favourites` (
  `id` bigint(20) NOT NULL,
  `ProductID_id` bigint(20) NOT NULL,
  `UserID_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eletrotechapp_like`
--

CREATE TABLE `eletrotechapp_like` (
  `id` bigint(20) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `like` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eletrotechapp_like`
--

INSERT INTO `eletrotechapp_like` (`id`, `post_id`, `user_id`, `like`) VALUES
(3, 3, 1, 'true'),
(4, 5, 1, 'False'),
(5, 4, 1, 'False'),
(6, 6, 1, 'False'),
(7, 1, 1, 'False');

-- --------------------------------------------------------

--
-- Table structure for table `eletrotechapp_payment`
--

CREATE TABLE `eletrotechapp_payment` (
  `id` bigint(20) NOT NULL,
  `CardNumber` varchar(200) NOT NULL,
  `cvv` int(11) NOT NULL,
  `expiry` varchar(20) NOT NULL,
  `PaidUser` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eletrotechapp_payment`
--

INSERT INTO `eletrotechapp_payment` (`id`, `CardNumber`, `cvv`, `expiry`, `PaidUser`) VALUES
(7, '1258125912365241', 369, '12/29', 'customer'),
(8, '123652365893', 325, '06/29', 'customer'),
(9, '123652365893', 325, '06/29', 'customer'),
(10, '1256987745633', 369, '06/26', 'customer'),
(11, '1236547896578', 987, '06/26', 'customer'),
(12, '1234123412341234', 123, '21/29', 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `eletrotechapp_products`
--

CREATE TABLE `eletrotechapp_products` (
  `id` bigint(20) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `ProductType` varchar(100) NOT NULL,
  `Description` longtext NOT NULL,
  `Price` int(11) NOT NULL,
  `Image` varchar(100) NOT NULL,
  `availability` int(11) NOT NULL,
  `likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eletrotechapp_products`
--

INSERT INTO `eletrotechapp_products` (`id`, `ProductName`, `ProductType`, `Description`, `Price`, `Image`, `availability`, `likes`) VALUES
(1, 'realme P1', 'mobiles', 'Discover the realme P1 5G, which offers strong performance and flawless connectivity thanks to the contemporary MediaTek Dimensity 7050 5G Chipset and Smart 5G features. Immerse yourself in vivid images on the 120Hz AMOLED display, which is supplemented with features like fingerprint recognition within the display and Sunlight Screen technology for readable content outside. With the 7-layer VC Cooling System, you can operate at the highest level without worrying about overheating when things get hot. With unparalleled performance and dependability, the realme P1 5G has a four-year smooth user experience guaranteed by TUV SUD certification, making it your reliable friend for years to come.', 15000, 'static/images/products/81bEtTGB4rL.jpg', 2, 0),
(2, 'SAMSUNG Galaxy F14', 'mobiles', 'The Samsung Galaxy F14 smartphone uses a segment-only 5nm processor that enables you with easy multitasking, gaming, and much more. It has a 6000 mAh battery that will last you for up to 2 days on a single charge. Thanks to the 5G connectivity, you can enjoy high speed browsing on this smartphone. It has a large display of about 16.72 cm (6.5) full HD+ display that enables you with immersive viewing. The 12 GB of RAM with RAM Plus offers enough storage space to store all your data. This smartphone’s OS updates and security updates keeps you updated and protected.', 11330, 'static/images/products/-original-imagtyxhuehakdc4.webp', 3, 0),
(3, 'MOTOROLA', 'homeappliance', 'Warranty is Non-transferrable, Valid Only in the Territory of India and Extended Only to the First End User Customer, Warranty will be Valid Only When the Original Purchase Invoice is Presented at the Time of Service, Warranty will Cover Only Functional Parts and Software Issues having Manufacturing Defects and Does Not Cover Damages Resulting from Un-authorised Adaptations, Adjustments, Tampering of the Product, Improper Installation of the Product, Normal Wear and Tear Caused Due to Use of Product, In Case of Commercial Usage of the Product, Warranty Period will be Limited to 90 Days Only.', 10890, 'static/images/products/download_3.jpeg', 3, 1),
(4, 'LG 322 L 3 Star Frost', 'homeappliance', 'Frost Free Refrigerator greater than 300 L: Auto defrost function to prevent ice-build up\r\nCapacity 322 L: Suitable for families with 5 or more members I freezer capacity: 81 L, fresh food capacity: 241 L\r\nEnergy Rating 3 Star: Energy efficiency\r\nManufacturer warranty: 1 year on product, 10 years on compressor T&C\r\nSmart inverter compressor – energy efficient, less noise & more durable\r\nStorage or Interior description: Total no of shelves - 02 (Trimless Tempered Glass); Vegetable box Capacity - 28 Ltr. (GPPS Transparent), Pull out tray – Slide out for easy reach, Egg Tray, Anti-bacterial gasket – Protects food from bacteria & dust, Anti rat bite (Steel Sleeve)', 35990, 'static/images/products/LG-GL-N412SDSY-Frost-Free-Refrigerators-493692141-i-1-1200Wx1200H.jpg', 3, 0),
(5, 'SAMSUNG 633 Litres', 'homeappliance', 'Sufficient Storage\r\n\r\nBuilt with a massive 633L storage capacity, the Samsung RS78CG8543SLHL 633L Frost-Free Side-by-Side-Door Refrigerator allows for the neat storage and organisation of different food items, from jam and pickle jars to milk packets and eggs. Additionally, this refrigerator, featuring a versatile space, can store a diverse range of beverages with ease. Thus, this refrigerator emerges as an ideal choice for households with expansive families, offering both space and functionality.\r\n\r\n\r\nTwin Cooling Plus Technology\r\n\r\nFeaturing Twin Cooling Plus technology, this refrigerator is designed to provide an optimal cooling environment, promising that every corner of the fridge maintains the ideal temperature for preserving the freshness of your stored items. So, this refrigerator helps preserve the nutritional content of fruits, vegetables, and other perishables.', 117800, 'static/images/products/267758_0_kicih5.png', 2, 0),
(6, 'Longway Super Dlx 750 Watt Juicer', 'homeappliance', 'Super Energy Efficient Motor : Elegant Design Comprises the energy efficient technology from Longway. Powerful Motor - 750 Watt, Gloss Finish with superb performance.\r\nBody Design/Features : Rust Proof ABS Plastic Body and Wide Jars set. Also, comes with the glossy finish and rust proof technology. Helps to enhance the consumer experience.\r\nProduct Features : 22000 RPM High Speed, Number of Speed setting - 3.\r\nPackage Content : Mixer Grinder including Mixer Motor, Jars Set, Jars Lids Set, Instruction Manual\r\nWarranty Period : 1 Years Limited Domestic Brand Warranty. Enjoy the hassle free warranty by Longway on your product.', 1499, 'static/images/products/71tVR9plCgL._AC_UF8941000_QL80_.jpg', 2, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `eletrotechapp_cart`
--
ALTER TABLE `eletrotechapp_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eletrotechapp_cart_ProductID_id_855f1e95_fk_eletrotec` (`ProductID_id`),
  ADD KEY `eletrotechapp_cart_UserID_id_2cc089f4_fk_eletrotec` (`UserID_id`);

--
-- Indexes for table `eletrotechapp_customers`
--
ALTER TABLE `eletrotechapp_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eletrotechapp_favourites`
--
ALTER TABLE `eletrotechapp_favourites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eletrotechapp_favour_ProductID_id_43e0f706_fk_eletrotec` (`ProductID_id`),
  ADD KEY `eletrotechapp_favour_UserID_id_f7da5e7e_fk_eletrotec` (`UserID_id`);

--
-- Indexes for table `eletrotechapp_like`
--
ALTER TABLE `eletrotechapp_like`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eletrotechapp_like_post_id_fe66c7c5_fk_eletrotechapp_products_id` (`post_id`),
  ADD KEY `eletrotechapp_like_user_id_089eaf6c_fk_eletrotec` (`user_id`);

--
-- Indexes for table `eletrotechapp_payment`
--
ALTER TABLE `eletrotechapp_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eletrotechapp_products`
--
ALTER TABLE `eletrotechapp_products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `eletrotechapp_cart`
--
ALTER TABLE `eletrotechapp_cart`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `eletrotechapp_customers`
--
ALTER TABLE `eletrotechapp_customers`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `eletrotechapp_favourites`
--
ALTER TABLE `eletrotechapp_favourites`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `eletrotechapp_like`
--
ALTER TABLE `eletrotechapp_like`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `eletrotechapp_payment`
--
ALTER TABLE `eletrotechapp_payment`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `eletrotechapp_products`
--
ALTER TABLE `eletrotechapp_products`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `eletrotechapp_cart`
--
ALTER TABLE `eletrotechapp_cart`
  ADD CONSTRAINT `eletrotechapp_cart_ProductID_id_855f1e95_fk_eletrotec` FOREIGN KEY (`ProductID_id`) REFERENCES `eletrotechapp_products` (`id`),
  ADD CONSTRAINT `eletrotechapp_cart_UserID_id_2cc089f4_fk_eletrotec` FOREIGN KEY (`UserID_id`) REFERENCES `eletrotechapp_customers` (`id`);

--
-- Constraints for table `eletrotechapp_favourites`
--
ALTER TABLE `eletrotechapp_favourites`
  ADD CONSTRAINT `eletrotechapp_favour_ProductID_id_43e0f706_fk_eletrotec` FOREIGN KEY (`ProductID_id`) REFERENCES `eletrotechapp_products` (`id`),
  ADD CONSTRAINT `eletrotechapp_favour_UserID_id_f7da5e7e_fk_eletrotec` FOREIGN KEY (`UserID_id`) REFERENCES `eletrotechapp_customers` (`id`);

--
-- Constraints for table `eletrotechapp_like`
--
ALTER TABLE `eletrotechapp_like`
  ADD CONSTRAINT `eletrotechapp_like_post_id_fe66c7c5_fk_eletrotechapp_products_id` FOREIGN KEY (`post_id`) REFERENCES `eletrotechapp_products` (`id`),
  ADD CONSTRAINT `eletrotechapp_like_user_id_089eaf6c_fk_eletrotec` FOREIGN KEY (`user_id`) REFERENCES `eletrotechapp_customers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
